---
---
Anyway to try to tie it back and not go too off the deepend, i guess i just wanna say...

Being poor is traumatic. Every day you struggle with any purchase, even if its sub $10. Feeling a sickening feeling of both relief and anxiety every time youre forced to buy something you unequivocally need. "Wow, its gonna be nice to soap up with Irish Spring again. Hope its worth potentially not being able to get groceries or pay a bill."

And no matter how practical you are on the regular, this lot in life leaves you with mutual contempt for everyone else who defaults to thinking your brokeness is your own fault. The kind of people who would point to a switch and do what aboutism, not questioning if it was a gift or whatever because poor ppl are forced to choose between joy and survival so much. And even if they pick survival 99/100, a mismanagement of assets have people snorting or whispering about them. 

Sighs. Literally just... Really hard. Really really hard. 

I legit dont want to interact with anyone "normie" anymore, i cant take the constant judgemental and "well im doing well anyway so shrug" atmosphere anymore