---
---
I've always found the concept of "coming out of the closet" being a one time thing to be an oversimplification of what it tends to be like. I've always found it more like you're in a room where people can hear you and there are various windows only visible to certain groups. Maybe you keep the curtains down in front of your parents while your lover just has it open.

The point is, I feel like declaring yourself outside the status quo is basically a constant question on your mind with everyone you meet. And I don't know if most people know how exhausting that can be.