---
---
I was looking at instagram and tiktok to see if I wanted to rebrand or delete accounts and I'm just like. Nah, fuck it. I refuse to deal with anything like tiktok, insta, facebook. You can text me the old fashioned way if you want (directed at people I meet outside) 

Like Aethy has all I need. The only thing I'd think of would be maybe a connected peertube but I have no idea whats out there with similar aethy atmosphere. I think shotatube shut down a while ago.

Like I'm not really kissing ass its just nice that I dont have to be anxious about locking posts up because we're exposed to the entire world. Im happy in this little pond, even if we only connect to the oceans in slow dribbling rivulets that feeling of security and genuine verbal/written engagement will bless my heart more than 10K views. (Although thats fun as well.) 

I like that the stats here also reflect that down to earth nature. Its kinda sad when instagram people call 100 likes a flop. Its somewhat understandable though because insta likes are literally seen as a currency almost with just trades and f4f and a big disconnect of the actual social aspect aside from number reaching.

What a lot of people dont realize is that yeah your stuff gets seen by a lot of people but the range is too wide. Im not gonna get into my spiel about niche and stuff, but its disheartening to see so many creators insist on X/Twitter despite being burned by it so much.

I understand Mastodon is a steep learning curve, a lot of this kinda stuff servers from UI overwhelm at first blush. But yeah I dont wanna feel like a waiting puppy for my reward of analytics. I wanna just be chillin and saying whats on my mind. Yeah i do filter and think about sentence stuff and minor hashtags bit it doesnt consume me anymore. I still obsessively check recent posts for engagement, but I dont get that dejected feeling if nothings there. At least being able to use my tag sorting system i can see whats going on for me

I know its not easy but the clutches the big social have on people is pretty severe dont you think?