---
---
Believe it or not, I used to like to dance a lot and make up choreography in my head to some songs. I wasn't able to do some of the moves I thought of, but I could improvise in between. I even won a dance contest at a convention some time in 2015 or so. 

But nowadays, its hard to even finish an average song without being completely inundated with either brutalizing pain, an asthma attack or both. I used to get out of breath easily but moving never caused me pain until around 2019, when walking to the store for groceries slowly became harder and took longer, even with my hand cart to carry the bags in. I started to get to a point where I was dreading getting groceries because it would take an hour to do the 15 minute walk with a few breaks in between to catch my breath and ease my back. 

Eventually, I switched to walmart delivery because with their plus plan because they took ebt and the only thing I had to do was bring the bags up 3 flights, which could still take up to 45 minutes, especially for heavy stuff.

I also used to be able to walk about 10 minutes to the bus stop to take it to my psychiatrist's appointments, until one day while walking to the bus stop, I was barely a block out from my house when a shooting pain when down the back of my leg and centered on my ankle, which was so bad even when I sat down I was crying out of frustration and shame.

From that point on, I had to use uber to get anywhere more than just outside my apartment building. And this made my agoraphobia even worse because outside = pain on top of everything else.

In 2021 when I was moving, I bought a rollator to help me, so I could have something to lean on for support without hunching over too much and a place to sit anytime I needed. Its helped me a lot since then, especially on frequent doctors visits.

The point I guess I'm trying to make here is my weight since I started losing strength was very stable (give or take a fluctuation of 10-15lbs) when the rapid decline started over the course of a year. Not to mention I had to go outside as frequently from month to month so it shouldn't have been atrophy.

So...basically I made this post because I was watching some beat saber videos that had inspired me a lot before and I couldn't even finish them because all I could think of was how I wasnt able to really do that anymore. That on top of having to constantly battle my drawing hand going numb because of nerve damage, it makes me extremely upset because Im not even 30 yet and this is already happening to me. 

Basically, its hard to see a future where I can get back to normal, especially when I sometimes legitimately have to ignore my numb hand to work on commissions to put a roof over my head. My turnaround time is atrocious. There, Ive said it. And the burden of guilt from 8 month+ commissions still not being done weighs on me anytime I try to rest whatsoever. 

Its like- these doctors expect me to do so much and tell me Im young... so I dont need SSI because I can work, and yet tell me to rest my arm with a brace and minimize movement, while not having basic income to fall back on. When my job is an Artist.

Make it fucking make sense.