---
---
Played a little bit of beat Saber for the first time in what feels like forever. Started switching in the middle of a song (Catgroove by Parov Stellar) probably because thinking about my FP who I had bought a quest and beat saber for to begin with since my meta account showed she was online 2 days ago and I kept disassociating thinking about it. 

Idk how to say this because i almost feel guilty about it, but the pain is starting not to be as sharp, even though its still there. Speaking of which my body aches warmly, but in like that good way. Alex 🦋  had also helped to feel fabulous while swinging and trying not to let our mind wander too much. Maybe its the fact that I started concentrating on the sabers being an extension of me and getting immersed in the swordness of it made me switch. 

Plus I had had a pretty interesting dream involving me, Charlie, Alastor and Fizzaroli which had also started with me and my best friend having died and both being accepted into heaven and being assured that it was real and she was allowed despite having been atheist because the important thing was she was a good person...It was like a larp or something, i dunno. -Vaggie 🦋 