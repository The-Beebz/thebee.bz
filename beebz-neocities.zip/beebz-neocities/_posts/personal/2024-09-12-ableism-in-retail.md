---
---
I get uncomfortable with how often people are able to make sweeping negative statements about people who leave an item in the wrong aisle, doesn't clean up or doesn't put the cart back in the corral.

I 100% think that retail workers deserve better than outright negligence on behalf of the customer, but the stuff people say over those who dont put the corral back is upsetting.

I get that it's partially venting as a worker, but as someone with a disability, an invisible disablity, it's stressful to feel like I have to choose between more pain or social shunning. The latter doesnt sound bad until you realize that some people will voice their disgust without knowing the whole story. THAT potentiality is just frightening.

Yes, I do my best to help, like I parked the scooter cart and lined it up nice, plugged it in. But if I have something not perishable that I changed my mind on, leaving it on a shelf in plain view isnt as bad as like hiding ice cream behind clothes or half drunk frappeccinos everywhere. 

If youre a retail worker getting more murderous (lighthearted) cleaning up, just pretend youre doing it for the spoonies. We thank you for your patience. 