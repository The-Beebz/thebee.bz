---
---
I'm making this journal to see if I can be convinced to come back and post anything or talk about updates. If the past 3 years wasnt hell on me enough, the fact that I kept getting fucked over for drawing and supporting the "wrong" kind of art just makes me fucking exhausted.

I've always followed Furaffinitys policies on art, no posting cub or loli or shota on here. I always kept those posts to inkbunny. Yet here and on multiple discord servers, people have labeled Triste as a cub in situations where he never was one. Triste has always been a representation of myself. He's short and chubby like I am. Plus my style is a pretty reasonable 4-6 heads tall proportions consistently. To the point I was so stressed out in 2018 and 2019 I felt pushed to do 1:7-1:8 and it felt awkward and awful.

And its like, why is everyone so obsessed with making sure they "don't condone pedophilia". This is literally the default stance of most people. I would say if you try to use statistics to prove otherwise, that's just being doomeristic. Even so, attacking art and literature does nothing to help victims of assault or molestation. Not only do many victims use art for cathartis, the messy thing ppl dont wanna talk about is it actively can also help would-be predators from moving onto real things.

Why do people take issue with that? Many claim the "slippery slope" fallacy that classifies taboo artwork as a sort of gateway drug to wanting to perform the actions irl. Do people get inspired by kinky art? Yeah. But people fail to acknowledge that this inspiration is typically within the confines of consensual adult relationships. You're furries. I'm sure you've heard of roleplay.

I dont even know why I'm talking about this because I already fear being attacked by random one liner "gotcha's" with people using the disgusting outdated terms such as "child porn" or worse "cheese pizza" (seriously, fuck you for trying to make it sound cute just so you can have an inside joke. If you took this as seriously as you claim, you would never.

Maybe it's because inkbunny helped me pay my rent when I was on the run from my mother who dislocated my knee.

Maybe it's because I've indulged in cub art and transgressive fiction as a teenager to project and vent about the severe abuse I went through.

Maybe it's because for disagreeing with a person on toyhouse saying nsfw feral art should be banned, they stalked my twitter posts and MADE AN ACCOUNT to show everyone my inkbunny only artwork, and then they were rewarded for the callout by my being banned for offsite stuff.

Maybe its because antis got my paypal banned which directly contributed to me being unable to work and getting homeless on the street in freezing January with my cat.

Maybe theres some part of me that hopes this won't have been a waste of time to write and I'd actually get some people agreeing with me on how fucked up these agendas are, harming real people to protect the fictional ones.

I just hate puritan behavior so goddamn much. I hate how smug and vicious they are, always hunting for the next person to crucify. I hate how there have been persistent stalkers of my friends spreading misleading lies for their own idea of vigilante justice. I hate the constant attempts to reeducate being met with effectively fingers in ears "lalala cant hear you pedo".

I hate having to be afraid to show my art and what makes me happy. It doesn't matter if I hide and tag and warn, people use it as leverage to find and attack as opposed to avoid or block.

Im just so tired of it all.