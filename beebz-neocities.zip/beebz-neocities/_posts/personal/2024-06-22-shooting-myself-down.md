---
---

These past few days every time i have an idea of something to do that is just even the slightest bit ambitious, its just like "okay so what?" What does it accomplish. How does it make my life better. and I can't think of any rebuttal so I just kinda throw the idea away. Its probably a result of me dealing with my childhood trauma that constantly beat down my art and hobbies but knowing this doesnt make it any easier or any less intense. If anything, it feels like a truth with moving goalposts that i cant really escape from. 

Like depriving myself of joy and shutting down emotionally doesn't help me "get things done" it does the opposite actually and makes everything feel like it doesnt matter because i'm doomed anyway for not working "as hard" even though i have cubital tunnel, i got boomer brain that it wasnt for working hard but because i played too much. Even though cubital tunnel is elbow based and i drew from the elbow like they always taught...

Worse than not being good enough, being told I had potential I wasnt hitting makes every achievement feel empty because "if I wasnt so 'lazy' " i could have done even better...thats why it feels like everything is my fault or worse "i brought it to my universe" because i couldnt stop thimking of bad things.