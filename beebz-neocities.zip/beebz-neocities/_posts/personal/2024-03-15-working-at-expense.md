---
---

It is difficult to be someone who wants to value their own well-being over maintaining a status-quo designed to maximize the happiness of others at one's own expense. Even more so challenging when a narrative is pushed that you should desire to be a good exploitee for the opportunity to arise for you to have a chance to become an exploiter in the future. It drives a lust for extravagance purely because many are subjected to destitution. 

We are taught to desire the best, even when such luxuries would be beyond resources we could make use of. Those that simply desire to be content, to have "enough", are perceived to be "lazy" instead of being seen as realistic. Yet the irony is that in the pursuit of this opulent SugarCandy Mountain, many use the bulk of what their bodies can give in their lifetime to maintain a saccharine lifestyle for those who couldn't even fathom an alternative. 