---
---
I was intending to dry my clothes with a hair dryer to speed things up so I could wear them, but then when I had the hair dryer in my hands and turned it on I literally started having a flashback to when I was a child and would use the hairdryer to help dry myself after i got out of the shower, copying my mom, and its a noise that gives me both comfort and tension. Because the hairdryer also meant a lot of things that I'm still like- unencrypting now its a lot holy crap. But hairdryer would stress me out mainly because of all the interactions I had with my mom. It was a sort of ritual where we were in the bathroom together, waiting for one to shower and then the other would, in a way of bonding. And sometimes she didn't feel like it or would make the conversation bad because of an argument or something. and all the times she combed my hair... god. I can kinda feel the spikes of the comb on my head and uugh... 

its a really unpleasant feeling of scraping my scalp and my yelps of pain are told .... to not do that it wasnt that hard. So they expected me to just take all the tangles pain as idk a sort of attempt so I could "pay" for not maintaining my hair. Even though the length and my age and my executive dysfunction meant I couldn't handle the daily hour just combing my hair. it made my head ached and I would use the small tooth comb too and scrape hard. Probably another side effect of always feeling so dirty. 

Man, its rare that I get a whole puzzle piece basically. Its like if you found a hairdryer puzzle in one of the To The Moon levels. 

I'm okay by the way, I say triggered in the literal sense but I dont have any strong need for comfort right now. I'm dealin~

I think getting these vivid childhood memories, despite having a lot of baggage, is a good sign of my ability to cope so far, because I do in a sense, want more of the ambition and vulgar passion I had in spite of everything, because I didn't know I didn't deserve it yet. 

thats deep bro heh