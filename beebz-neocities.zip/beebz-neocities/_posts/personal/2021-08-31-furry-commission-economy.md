---
---
A vast majority of furaffinity's audience and just chunk of the furry community in general is primarily focused on the idea of original characters and interaction with other people through roleplay, writing, or pictures to represent the friendship between the creators of the characters. This makes the primary focus of the furry fandom original content. 

Compare this to a place like deviantart, which is marketed for artists. Most people there. are artists, so they make their own art. There is a good oc community on it too, but the interests of the site are spread far and wide in order to be palateable for a wider audience. It is the Facebook of art is another way of putting it. 

In the furry fandom, many people are just appreciators of art, and because they have original characters, instead of say, being interested primarily in preexisting properties, it is rare for them to get art of their original characters en masse for free or cheap, and even then, a majority of the furry community looks down on that complex. 

Therefore, unlike anime communities, which gets pumped so full of fanart for free that it becomes a commodity, coupled with getting whiny people asking you to draw THEIR fav character instead or THAT ship, and unlike art communities, which, whether on purpose or not, is filled with very self centered people, the furry community is more focused on just that, COMMUNITY, interaction, building upon their characters and there is a healthy mix of both creators and consumers of art. 

Which then in turn creates a healthier than normal commission economy.